from django.contrib import admin

from app.models import Seller

admin.site.register(Seller)
